import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

export type WritingProfileType = "creative-writing" | "academic-papers" | "blog-posts" | "custom";

export interface WritingProfileSettings {
  name: string;
  description: string;
  tone: "creative" | "formal" | "conversational" | "academic" | "casual" | "professional" | "inspirational";
  vocabularyLevel: "simple" | "moderate" | "advanced" | "technical" | "varied";
  sentenceStructure: "short-punchy" | "varied" | "complex" | "flowing" | "academic";
  styleInstructions: string;
  targetAudience: string;
  focusArea: "narrative" | "analytical" | "persuasive" | "informative" | "entertaining";
  aiSystemPromptAddition: string;
}

const DEFAULT_WRITING_PROFILES: Record<WritingProfileType, WritingProfileSettings> = {
  "creative-writing": {
    name: "Creative Writing",
    description: "For novels, short stories, and creative fiction",
    tone: "creative",
    vocabularyLevel: "varied",
    sentenceStructure: "varied",
    styleInstructions: "Use vivid imagery, show don't tell, create emotional connections, develop character voice, and maintain narrative flow. Embrace literary devices like metaphors, similes, and sensory details.",
    targetAudience: "General readers seeking engaging stories",
    focusArea: "narrative",
    aiSystemPromptAddition: "You are a creative fiction writer. Focus on storytelling, character development, vivid descriptions, and emotional resonance. Use varied sentence structures, rich vocabulary, and literary techniques. Show rather than tell, and create immersive scenes that draw readers in.",
  },
  "academic-papers": {
    name: "Academic Papers",
    description: "For research papers, essays, and scholarly writing",
    tone: "academic",
    vocabularyLevel: "technical",
    sentenceStructure: "complex",
    styleInstructions: "Use formal language, cite sources appropriately, maintain objectivity, use precise terminology, and follow academic conventions. Structure arguments logically with clear thesis statements and supporting evidence.",
    targetAudience: "Academic readers, researchers, and scholars",
    focusArea: "analytical",
    aiSystemPromptAddition: "You are an academic writer. Use formal, scholarly language with precise terminology. Maintain objectivity and support all claims with evidence. Structure arguments logically with clear topic sentences. Avoid colloquialisms, contractions, and casual language. Use complex sentence structures appropriate for academic discourse.",
  },
  "blog-posts": {
    name: "Blog Posts",
    description: "For online articles, blog content, and web writing",
    tone: "conversational",
    vocabularyLevel: "moderate",
    sentenceStructure: "short-punchy",
    styleInstructions: "Write in a friendly, accessible tone. Use short paragraphs, subheadings, and bullet points. Address the reader directly using 'you'. Include practical examples and actionable advice. Keep sentences concise and scannable.",
    targetAudience: "Online readers seeking practical information",
    focusArea: "informative",
    aiSystemPromptAddition: "You are a blog writer. Use a conversational, friendly tone that connects with readers. Write in short, punchy sentences and paragraphs that are easy to scan. Use subheadings, bullet points, and practical examples. Address the reader directly with 'you'. Make content actionable and engaging for online audiences.",
  },
  "custom": {
    name: "Custom Profile",
    description: "Your personalized writing configuration",
    tone: "conversational",
    vocabularyLevel: "moderate",
    sentenceStructure: "varied",
    styleInstructions: "Follow the user's custom preferences",
    targetAudience: "Defined by user",
    focusArea: "informative",
    aiSystemPromptAddition: "",
  },
};

interface WritingProfileStore {
  activeProfile: WritingProfileType;
  customSettings: Partial<WritingProfileSettings>;
  setActiveProfile: (profile: WritingProfileType) => void;
  updateCustomSettings: (settings: Partial<WritingProfileSettings>) => void;
  getProfileSettings: () => WritingProfileSettings;
  resetToDefaults: () => void;
}

export const useWritingProfileStore = create<WritingProfileStore>()(
  persist(
    (set, get) => ({
      activeProfile: "creative-writing",
      customSettings: {},
      
      setActiveProfile: (profile) => set({ activeProfile: profile }),
      
      updateCustomSettings: (settings) =>
        set((state) => ({
          customSettings: { ...state.customSettings, ...settings },
        })),
      
      getProfileSettings: () => {
        const state = get();
        const baseSettings = DEFAULT_WRITING_PROFILES[state.activeProfile];
        
        // If custom profile, merge with custom settings
        if (state.activeProfile === "custom") {
          return {
            ...baseSettings,
            ...state.customSettings,
          };
        }
        
        return baseSettings;
      },
      
      resetToDefaults: () => set({ customSettings: {} }),
    }),
    {
      name: "writing-profile-storage",
      storage: createJSONStorage(() => localStorage),
    }
  )
);

// Helper hook to get the current profile settings
export const useCurrentWritingProfile = () =>
  useWritingProfileStore((state) => state.getProfileSettings());

// Helper hook to get all available profiles
export const useAvailableWritingProfiles = () => DEFAULT_WRITING_PROFILES;

// Helper to check if a specific profile is active
export const useIsProfileActive = (profile: WritingProfileType) =>
  useWritingProfileStore((state) => state.activeProfile === profile);
