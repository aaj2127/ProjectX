import { Fragment, useState, useEffect } from "react";
import { Dialog, Transition } from "@headlessui/react";
import { X, User, Sparkles, Zap, Minimize2, Rocket, Focus, Check, Feather, BookOpen, PenTool } from "lucide-react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { useWritingProfileStore, WritingProfileType, useCurrentWritingProfile } from "~/stores/writingProfileStore";

interface UserSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProfile: string;
  currentPreferences: any;
  onSave: (data: { uxProfile?: string; preferences?: any }) => void;
  isLoading?: boolean;
}

const UX_PROFILES = [
  {
    id: "novice",
    name: "Novice",
    icon: User,
    color: "from-blue-500 to-cyan-500",
    description: "Perfect for beginners",
    features: [
      "Simplified interface with helpful tooltips",
      "Guided workflows and onboarding",
      "Step-by-step instructions",
      "Reduced complexity and clutter",
    ],
  },
  {
    id: "expert",
    name: "Expert",
    icon: Zap,
    color: "from-purple-500 to-pink-500",
    description: "For power users",
    features: [
      "All features visible and accessible",
      "Keyboard shortcuts enabled",
      "Advanced AI tools and settings",
      "Batch operations and automation",
    ],
  },
  {
    id: "minimalist",
    name: "Minimalist",
    icon: Minimize2,
    color: "from-gray-500 to-slate-500",
    description: "Clean and distraction-free",
    features: [
      "Essential features only",
      "Minimal UI elements",
      "Focus on content creation",
      "Reduced visual noise",
    ],
  },
  {
    id: "fast-publish",
    name: "Fast Publish",
    icon: Rocket,
    color: "from-orange-500 to-red-500",
    description: "Optimized for speed",
    features: [
      "Streamlined creation workflow",
      "Quick export options",
      "One-click AI generation",
      "Rapid iteration tools",
    ],
  },
  {
    id: "adhd-friendly",
    name: "ADHD-Friendly",
    icon: Focus,
    color: "from-green-500 to-emerald-500",
    description: "Designed for focus",
    features: [
      "Reduced distractions and animations",
      "Clear progress indicators",
      "Breaking tasks into small steps",
      "Focus mode and timers",
    ],
  },
];

export function UserSettingsModal({
  isOpen,
  onClose,
  currentProfile,
  currentPreferences,
  onSave,
  isLoading = false,
}: UserSettingsModalProps) {
  const [selectedProfile, setSelectedProfile] = useState(currentProfile || "novice");
  
  // Get writing profile settings
  const writingProfile = useWritingProfileStore((state) => state.activeProfile);
  const writingProfileSettings = useCurrentWritingProfile();
  
  const { register, handleSubmit, watch } = useForm({
    defaultValues: {
      autoSave: currentPreferences?.autoSave ?? true,
      autoSaveInterval: currentPreferences?.autoSaveInterval ?? 3,
      showTooltips: currentPreferences?.showTooltips ?? true,
      keyboardShortcuts: currentPreferences?.keyboardShortcuts ?? true,
      aiSuggestions: currentPreferences?.aiSuggestions ?? "on-demand",
      focusMode: currentPreferences?.focusMode ?? false,
      wordCountGoal: currentPreferences?.wordCountGoal ?? 0,
      notificationEmail: currentPreferences?.notifications?.email ?? true,
      notificationPush: currentPreferences?.notifications?.push ?? false,
      notificationAchievements: currentPreferences?.notifications?.achievements ?? true,
      notificationCollaboration: currentPreferences?.notifications?.collaboration ?? true,
      // ADHD Copilot preferences
      copilotPersonality: currentPreferences?.copilotPersonality ?? "encouraging",
      copilotMessageFrequency: currentPreferences?.copilotMessageFrequency ?? "moderate",
      copilotBreakInterval: currentPreferences?.copilotBreakInterval ?? 25,
      copilotCheckInInterval: currentPreferences?.copilotCheckInInterval ?? 15,
      // Writing profile preferences
      writingProfile: currentPreferences?.writingProfile ?? writingProfile,
      writingProfileTone: currentPreferences?.writingProfileCustom?.tone ?? writingProfileSettings.tone,
      writingProfileVocabulary: currentPreferences?.writingProfileCustom?.vocabularyLevel ?? writingProfileSettings.vocabularyLevel,
      writingProfileSentenceStructure: currentPreferences?.writingProfileCustom?.sentenceStructure ?? writingProfileSettings.sentenceStructure,
      writingProfileFocusArea: currentPreferences?.writingProfileCustom?.focusArea ?? writingProfileSettings.focusArea,
      writingProfileTargetAudience: currentPreferences?.writingProfileCustom?.targetAudience ?? writingProfileSettings.targetAudience,
      writingProfileStyleInstructions: currentPreferences?.writingProfileCustom?.styleInstructions ?? writingProfileSettings.styleInstructions,
    },
  });

  const autoSaveEnabled = watch("autoSave");
  
  const [selectedWritingProfile, setSelectedWritingProfile] = useState<WritingProfileType>(
    (currentPreferences?.writingProfile as WritingProfileType) || writingProfile
  );
  const watchWritingProfile = watch("writingProfile");

  useEffect(() => {
    if (watchWritingProfile) {
      setSelectedWritingProfile(watchWritingProfile as WritingProfileType);
    }
  }, [watchWritingProfile]);

  const handleFormSubmit = (data: any) => {
    const preferences = {
      autoSave: data.autoSave,
      autoSaveInterval: data.autoSaveInterval,
      showTooltips: data.showTooltips,
      keyboardShortcuts: data.keyboardShortcuts,
      aiSuggestions: data.aiSuggestions,
      focusMode: data.focusMode,
      wordCountGoal: data.wordCountGoal,
      notifications: {
        email: data.notificationEmail,
        push: data.notificationPush,
        achievements: data.notificationAchievements,
        collaboration: data.notificationCollaboration,
      },
      // ADHD Copilot preferences
      copilotPersonality: data.copilotPersonality,
      copilotMessageFrequency: data.copilotMessageFrequency,
      copilotBreakInterval: data.copilotBreakInterval,
      copilotCheckInInterval: data.copilotCheckInInterval,
      // Writing profile preferences
      writingProfile: data.writingProfile,
      writingProfileCustom: selectedWritingProfile === "custom" ? {
        tone: data.writingProfileTone,
        vocabularyLevel: data.writingProfileVocabulary,
        sentenceStructure: data.writingProfileSentenceStructure,
        focusArea: data.writingProfileFocusArea,
        targetAudience: data.writingProfileTargetAudience,
        styleInstructions: data.writingProfileStyleInstructions,
      } : undefined,
    };

    // Also update the Zustand store
    const setActiveProfile = useWritingProfileStore.getState().setActiveProfile;
    const updateCustomSettings = useWritingProfileStore.getState().updateCustomSettings;
    
    setActiveProfile(data.writingProfile as WritingProfileType);
    
    if (selectedWritingProfile === "custom") {
      updateCustomSettings({
        tone: data.writingProfileTone,
        vocabularyLevel: data.writingProfileVocabulary,
        sentenceStructure: data.writingProfileSentenceStructure,
        focusArea: data.writingProfileFocusArea,
        targetAudience: data.writingProfileTargetAudience,
        styleInstructions: data.writingProfileStyleInstructions,
      });
    }

    onSave({
      uxProfile: selectedProfile,
      preferences,
    });
  };

  return (
    <Transition appear show={isOpen} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={onClose}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black bg-opacity-25" />
        </Transition.Child>

        <div className="fixed inset-0 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 scale-95"
              enterTo="opacity-100 scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 scale-100"
              leaveTo="opacity-0 scale-95"
            >
              <Dialog.Panel className="w-full max-w-5xl transform overflow-hidden rounded-3xl bg-white p-8 shadow-2xl transition-all max-h-[90vh] overflow-y-auto">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <div className="bg-gradient-to-br from-indigo-600 to-purple-600 p-3 rounded-xl shadow-lg">
                      <User className="w-7 h-7 text-white" />
                    </div>
                    <div>
                      <Dialog.Title className="text-2xl font-bold text-gray-900">
                        User Settings
                      </Dialog.Title>
                      <p className="text-sm text-gray-600">
                        Customize your Xavier Studio experience
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={onClose}
                    className="text-gray-400 hover:text-gray-600 p-2 hover:bg-gray-100 rounded-lg transition"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-8">
                  {/* UX Profile Selection */}
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                      <Sparkles className="w-5 h-5 mr-2 text-indigo-600" />
                      Choose Your Experience
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {UX_PROFILES.map((profile) => {
                        const Icon = profile.icon;
                        const isSelected = selectedProfile === profile.id;
                        return (
                          <button
                            key={profile.id}
                            type="button"
                            onClick={() => setSelectedProfile(profile.id)}
                            className={`relative p-6 rounded-2xl border-2 transition-all text-left ${
                              isSelected
                                ? "border-indigo-600 bg-indigo-50 shadow-lg transform scale-105"
                                : "border-gray-200 bg-white hover:border-gray-300 hover:shadow-md"
                            }`}
                          >
                            {isSelected && (
                              <div className="absolute top-3 right-3 bg-indigo-600 rounded-full p-1">
                                <Check className="w-4 h-4 text-white" />
                              </div>
                            )}
                            <div className={`bg-gradient-to-br ${profile.color} w-12 h-12 rounded-xl flex items-center justify-center mb-3 shadow-md`}>
                              <Icon className="w-6 h-6 text-white" />
                            </div>
                            <h4 className="font-bold text-gray-900 mb-1">{profile.name}</h4>
                            <p className="text-sm text-gray-600 mb-3">{profile.description}</p>
                            <ul className="space-y-1">
                              {profile.features.map((feature, idx) => (
                                <li key={idx} className="text-xs text-gray-500 flex items-start">
                                  <span className="text-indigo-600 mr-1">•</span>
                                  <span>{feature}</span>
                                </li>
                              ))}
                            </ul>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Editor Preferences */}
                  <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-6 border-2 border-blue-100">
                    <h3 className="text-lg font-bold text-gray-900 mb-4">
                      ⚙️ Editor Preferences
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="flex items-center space-x-3 cursor-pointer">
                          <input
                            type="checkbox"
                            {...register("autoSave")}
                            className="w-5 h-5 text-indigo-600 rounded focus:ring-2 focus:ring-indigo-500"
                          />
                          <div>
                            <span className="font-semibold text-gray-900">Auto-Save</span>
                            <p className="text-xs text-gray-600">Automatically save your work</p>
                          </div>
                        </label>
                        {autoSaveEnabled && (
                          <div className="mt-3 ml-8">
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Save interval (seconds)
                            </label>
                            <input
                              type="number"
                              {...register("autoSaveInterval", { min: 1, max: 60 })}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                            />
                          </div>
                        )}
                      </div>

                      <div>
                        <label className="flex items-center space-x-3 cursor-pointer">
                          <input
                            type="checkbox"
                            {...register("showTooltips")}
                            className="w-5 h-5 text-indigo-600 rounded focus:ring-2 focus:ring-indigo-500"
                          />
                          <div>
                            <span className="font-semibold text-gray-900">Show Tooltips</span>
                            <p className="text-xs text-gray-600">Display helpful hints</p>
                          </div>
                        </label>
                      </div>

                      <div>
                        <label className="flex items-center space-x-3 cursor-pointer">
                          <input
                            type="checkbox"
                            {...register("keyboardShortcuts")}
                            className="w-5 h-5 text-indigo-600 rounded focus:ring-2 focus:ring-indigo-500"
                          />
                          <div>
                            <span className="font-semibold text-gray-900">Keyboard Shortcuts</span>
                            <p className="text-xs text-gray-600">Enable hotkeys</p>
                          </div>
                        </label>
                      </div>

                      <div>
                        <label className="flex items-center space-x-3 cursor-pointer">
                          <input
                            type="checkbox"
                            {...register("focusMode")}
                            className="w-5 h-5 text-indigo-600 rounded focus:ring-2 focus:ring-indigo-500"
                          />
                          <div>
                            <span className="font-semibold text-gray-900">Focus Mode</span>
                            <p className="text-xs text-gray-600">Minimize distractions</p>
                          </div>
                        </label>
                      </div>

                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          AI Suggestions
                        </label>
                        <select
                          {...register("aiSuggestions")}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                        >
                          <option value="always">Always show suggestions</option>
                          <option value="on-demand">Show on demand</option>
                          <option value="never">Never show suggestions</option>
                        </select>
                      </div>

                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Daily Word Count Goal
                        </label>
                        <input
                          type="number"
                          {...register("wordCountGoal", { min: 0 })}
                          placeholder="0 = no goal"
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                        />
                        <p className="text-xs text-gray-500 mt-1">Set to 0 to disable</p>
                      </div>
                    </div>
                  </div>

                  {/* Notification Preferences */}
                  <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-6 border-2 border-purple-100">
                    <h3 className="text-lg font-bold text-gray-900 mb-4">
                      🔔 Notifications
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <label className="flex items-center space-x-3 cursor-pointer">
                        <input
                          type="checkbox"
                          {...register("notificationEmail")}
                          className="w-5 h-5 text-purple-600 rounded focus:ring-2 focus:ring-purple-500"
                        />
                        <div>
                          <span className="font-semibold text-gray-900">Email Notifications</span>
                          <p className="text-xs text-gray-600">Updates via email</p>
                        </div>
                      </label>

                      <label className="flex items-center space-x-3 cursor-pointer">
                        <input
                          type="checkbox"
                          {...register("notificationPush")}
                          className="w-5 h-5 text-purple-600 rounded focus:ring-2 focus:ring-purple-500"
                        />
                        <div>
                          <span className="font-semibold text-gray-900">Push Notifications</span>
                          <p className="text-xs text-gray-600">Browser alerts</p>
                        </div>
                      </label>

                      <label className="flex items-center space-x-3 cursor-pointer">
                        <input
                          type="checkbox"
                          {...register("notificationAchievements")}
                          className="w-5 h-5 text-purple-600 rounded focus:ring-2 focus:ring-purple-500"
                        />
                        <div>
                          <span className="font-semibold text-gray-900">Achievements</span>
                          <p className="text-xs text-gray-600">Milestone alerts</p>
                        </div>
                      </label>

                      <label className="flex items-center space-x-3 cursor-pointer">
                        <input
                          type="checkbox"
                          {...register("notificationCollaboration")}
                          className="w-5 h-5 text-purple-600 rounded focus:ring-2 focus:ring-purple-500"
                        />
                        <div>
                          <span className="font-semibold text-gray-900">Collaboration</span>
                          <p className="text-xs text-gray-600">Team updates</p>
                        </div>
                      </label>
                    </div>
                  </div>

                  {/* ADHD Copilot Settings */}
                  <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-6 border-2 border-green-100">
                    <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                      <Focus className="w-5 h-5 mr-2 text-green-600" />
                      ADHD Copilot Settings
                    </h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Customize your writing companion to match your personal work style
                    </p>
                    
                    <div className="space-y-6">
                      {/* Personality Selection */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-3">
                          Copilot Personality
                        </label>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                          <label className="relative flex items-start p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:border-green-300 transition has-[:checked]:border-green-500 has-[:checked]:bg-green-50">
                            <input
                              type="radio"
                              value="encouraging"
                              {...register("copilotPersonality")}
                              className="mt-1 h-4 w-4 text-green-600 focus:ring-green-500"
                            />
                            <div className="ml-3">
                              <span className="block text-sm font-semibold text-gray-900">
                                🌟 Encouraging
                              </span>
                              <span className="block text-xs text-gray-600 mt-1">
                                Warm, upbeat, and motivational
                              </span>
                            </div>
                          </label>
                          
                          <label className="relative flex items-start p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:border-green-300 transition has-[:checked]:border-green-500 has-[:checked]:bg-green-50">
                            <input
                              type="radio"
                              value="gentle"
                              {...register("copilotPersonality")}
                              className="mt-1 h-4 w-4 text-green-600 focus:ring-green-500"
                            />
                            <div className="ml-3">
                              <span className="block text-sm font-semibold text-gray-900">
                                🌸 Gentle
                              </span>
                              <span className="block text-xs text-gray-600 mt-1">
                                Calm, soothing, and patient
                              </span>
                            </div>
                          </label>
                          
                          <label className="relative flex items-start p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:border-green-300 transition has-[:checked]:border-green-500 has-[:checked]:bg-green-50">
                            <input
                              type="radio"
                              value="energetic"
                              {...register("copilotPersonality")}
                              className="mt-1 h-4 w-4 text-green-600 focus:ring-green-500"
                            />
                            <div className="ml-3">
                              <span className="block text-sm font-semibold text-gray-900">
                                ⚡ Energetic
                              </span>
                              <span className="block text-xs text-gray-600 mt-1">
                                Dynamic and action-focused
                              </span>
                            </div>
                          </label>
                        </div>
                      </div>

                      {/* Message Frequency */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-3">
                          Message Frequency
                        </label>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                          <label className="relative flex items-start p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:border-green-300 transition has-[:checked]:border-green-500 has-[:checked]:bg-green-50">
                            <input
                              type="radio"
                              value="minimal"
                              {...register("copilotMessageFrequency")}
                              className="mt-1 h-4 w-4 text-green-600 focus:ring-green-500"
                            />
                            <div className="ml-3">
                              <span className="block text-sm font-semibold text-gray-900">
                                Minimal
                              </span>
                              <span className="block text-xs text-gray-600 mt-1">
                                Less frequent check-ins
                              </span>
                            </div>
                          </label>
                          
                          <label className="relative flex items-start p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:border-green-300 transition has-[:checked]:border-green-500 has-[:checked]:bg-green-50">
                            <input
                              type="radio"
                              value="moderate"
                              {...register("copilotMessageFrequency")}
                              className="mt-1 h-4 w-4 text-green-600 focus:ring-green-500"
                            />
                            <div className="ml-3">
                              <span className="block text-sm font-semibold text-gray-900">
                                Moderate
                              </span>
                              <span className="block text-xs text-gray-600 mt-1">
                                Balanced frequency (default)
                              </span>
                            </div>
                          </label>
                          
                          <label className="relative flex items-start p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:border-green-300 transition has-[:checked]:border-green-500 has-[:checked]:bg-green-50">
                            <input
                              type="radio"
                              value="frequent"
                              {...register("copilotMessageFrequency")}
                              className="mt-1 h-4 w-4 text-green-600 focus:ring-green-500"
                            />
                            <div className="ml-3">
                              <span className="block text-sm font-semibold text-gray-900">
                                Frequent
                              </span>
                              <span className="block text-xs text-gray-600 mt-1">
                                More regular support
                              </span>
                            </div>
                          </label>
                        </div>
                      </div>

                      {/* Time Intervals */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Break Reminder Interval (minutes)
                          </label>
                          <input
                            type="number"
                            {...register("copilotBreakInterval", { 
                              min: 5, 
                              max: 120,
                              valueAsNumber: true 
                            })}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                          />
                          <p className="text-xs text-gray-500 mt-1">
                            Default: 25 minutes (Pomodoro)
                          </p>
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Check-in Interval (minutes)
                          </label>
                          <input
                            type="number"
                            {...register("copilotCheckInInterval", { 
                              min: 5, 
                              max: 60,
                              valueAsNumber: true 
                            })}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                          />
                          <p className="text-xs text-gray-500 mt-1">
                            Default: 15 minutes
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Writing Profile Settings */}
                  <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-6 border-2 border-purple-100">
                    <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                      <Feather className="w-5 h-5 mr-2 text-purple-600" />
                      AI Writing Style Configuration
                    </h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Choose how the AI should write for different types of content
                    </p>
                    
                    <div className="space-y-6">
                      {/* Profile Selection */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-3">
                          Select Writing Profile
                        </label>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <label className="relative flex items-start p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:border-purple-300 transition has-[:checked]:border-purple-500 has-[:checked]:bg-purple-50">
                            <input
                              type="radio"
                              value="creative-writing"
                              {...register("writingProfile")}
                              className="mt-1 h-4 w-4 text-purple-600 focus:ring-purple-500"
                            />
                            <div className="ml-3 flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <Feather className="w-4 h-4 text-purple-600" />
                                <span className="block text-sm font-semibold text-gray-900">
                                  Creative Writing
                                </span>
                              </div>
                              <span className="block text-xs text-gray-600">
                                For novels, stories, and creative fiction
                              </span>
                            </div>
                          </label>
                          
                          <label className="relative flex items-start p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:border-purple-300 transition has-[:checked]:border-purple-500 has-[:checked]:bg-purple-50">
                            <input
                              type="radio"
                              value="academic-papers"
                              {...register("writingProfile")}
                              className="mt-1 h-4 w-4 text-purple-600 focus:ring-purple-500"
                            />
                            <div className="ml-3 flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <BookOpen className="w-4 h-4 text-blue-600" />
                                <span className="block text-sm font-semibold text-gray-900">
                                  Academic Papers
                                </span>
                              </div>
                              <span className="block text-xs text-gray-600">
                                For research papers and scholarly writing
                              </span>
                            </div>
                          </label>
                          
                          <label className="relative flex items-start p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:border-purple-300 transition has-[:checked]:border-purple-500 has-[:checked]:bg-purple-50">
                            <input
                              type="radio"
                              value="blog-posts"
                              {...register("writingProfile")}
                              className="mt-1 h-4 w-4 text-purple-600 focus:ring-purple-500"
                            />
                            <div className="ml-3 flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <PenTool className="w-4 h-4 text-orange-600" />
                                <span className="block text-sm font-semibold text-gray-900">
                                  Blog Posts
                                </span>
                              </div>
                              <span className="block text-xs text-gray-600">
                                For online articles and web content
                              </span>
                            </div>
                          </label>
                          
                          <label className="relative flex items-start p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:border-purple-300 transition has-[:checked]:border-purple-500 has-[:checked]:bg-purple-50">
                            <input
                              type="radio"
                              value="custom"
                              {...register("writingProfile")}
                              className="mt-1 h-4 w-4 text-purple-600 focus:ring-purple-500"
                            />
                            <div className="ml-3 flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <Sparkles className="w-4 h-4 text-purple-600" />
                                <span className="block text-sm font-semibold text-gray-900">
                                  Custom Profile
                                </span>
                              </div>
                              <span className="block text-xs text-gray-600">
                                Configure your own style preferences
                              </span>
                            </div>
                          </label>
                        </div>
                      </div>

                      {/* Custom Profile Settings - Only show when custom is selected */}
                      {selectedWritingProfile === "custom" && (
                        <div className="bg-white rounded-xl p-4 border-2 border-purple-200 space-y-4">
                          <h4 className="font-bold text-gray-900 text-sm mb-3">
                            Custom Profile Configuration
                          </h4>
                          
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Tone
                            </label>
                            <select
                              {...register("writingProfileTone")}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                            >
                              <option value="creative">Creative</option>
                              <option value="formal">Formal</option>
                              <option value="conversational">Conversational</option>
                              <option value="academic">Academic</option>
                              <option value="casual">Casual</option>
                              <option value="professional">Professional</option>
                              <option value="inspirational">Inspirational</option>
                            </select>
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Vocabulary Level
                            </label>
                            <select
                              {...register("writingProfileVocabulary")}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                            >
                              <option value="simple">Simple</option>
                              <option value="moderate">Moderate</option>
                              <option value="advanced">Advanced</option>
                              <option value="technical">Technical</option>
                              <option value="varied">Varied</option>
                            </select>
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Sentence Structure
                            </label>
                            <select
                              {...register("writingProfileSentenceStructure")}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                            >
                              <option value="short-punchy">Short & Punchy</option>
                              <option value="varied">Varied</option>
                              <option value="complex">Complex</option>
                              <option value="flowing">Flowing</option>
                              <option value="academic">Academic</option>
                            </select>
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Focus Area
                            </label>
                            <select
                              {...register("writingProfileFocusArea")}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                            >
                              <option value="narrative">Narrative</option>
                              <option value="analytical">Analytical</option>
                              <option value="persuasive">Persuasive</option>
                              <option value="informative">Informative</option>
                              <option value="entertaining">Entertaining</option>
                            </select>
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Target Audience
                            </label>
                            <input
                              type="text"
                              {...register("writingProfileTargetAudience")}
                              placeholder="e.g., Young adults, professionals, general readers"
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                            />
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Style Instructions
                            </label>
                            <textarea
                              {...register("writingProfileStyleInstructions")}
                              rows={3}
                              placeholder="Describe how you want the AI to write..."
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                            />
                            <p className="text-xs text-gray-500 mt-1">
                              Provide specific instructions for the AI's writing style
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex space-x-3 pt-4">
                    <button
                      type="button"
                      onClick={onClose}
                      className="flex-1 px-6 py-3 border-2 border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isLoading}
                      className="flex-1 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl font-bold hover:from-indigo-700 hover:to-purple-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg transform hover:scale-105"
                    >
                      {isLoading ? "Saving..." : "Save Settings"}
                    </button>
                  </div>
                </form>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
}
