import { Fragment } from "react";
import { Menu, Transition } from "@headlessui/react";
import { Feather, BookOpen, PenTool, ChevronDown, Check } from "lucide-react";
import { useWritingProfileStore, WritingProfileType, useCurrentWritingProfile, useAvailableWritingProfiles } from "~/stores/writingProfileStore";
import { soundEffects } from "~/utils/soundEffects";

const PROFILE_ICONS: Record<WritingProfileType, any> = {
  "creative-writing": Feather,
  "academic-papers": BookOpen,
  "blog-posts": PenTool,
  "custom": PenTool,
};

const PROFILE_COLORS: Record<WritingProfileType, string> = {
  "creative-writing": "from-purple-500 to-pink-500",
  "academic-papers": "from-blue-500 to-indigo-500",
  "blog-posts": "from-orange-500 to-red-500",
  "custom": "from-gray-500 to-slate-500",
};

export function WritingProfileSelector() {
  const activeProfile = useWritingProfileStore((state) => state.activeProfile);
  const setActiveProfile = useWritingProfileStore((state) => state.setActiveProfile);
  const currentSettings = useCurrentWritingProfile();
  const availableProfiles = useAvailableWritingProfiles();

  const ActiveIcon = PROFILE_ICONS[activeProfile];
  const activeColor = PROFILE_COLORS[activeProfile];

  const handleProfileChange = (profile: WritingProfileType) => {
    setActiveProfile(profile);
    soundEffects.click();
  };

  return (
    <Menu as="div" className="relative inline-block text-left">
      <Menu.Button className="flex items-center space-x-2 px-4 py-2 bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-xl hover:border-purple-300 dark:hover:border-purple-600 transition-all shadow-sm hover:shadow-md group">
        <div className={`bg-gradient-to-br ${activeColor} p-1.5 rounded-lg group-hover:scale-110 transition-transform`}>
          <ActiveIcon className="w-4 h-4 text-white" />
        </div>
        <div className="text-left">
          <div className="text-sm font-bold text-gray-900 dark:text-gray-100">
            {currentSettings.name}
          </div>
          <div className="text-xs text-gray-500 dark:text-gray-400">
            Writing Style
          </div>
        </div>
        <ChevronDown className="w-4 h-4 text-gray-500 dark:text-gray-400 group-hover:text-purple-600 transition-colors" />
      </Menu.Button>

      <Transition
        as={Fragment}
        enter="transition ease-out duration-100"
        enterFrom="transform opacity-0 scale-95"
        enterTo="transform opacity-100 scale-100"
        leave="transition ease-in duration-75"
        leaveFrom="transform opacity-100 scale-100"
        leaveTo="transform opacity-0 scale-95"
      >
        <Menu.Items className="absolute right-0 mt-2 w-80 origin-top-right rounded-2xl bg-white dark:bg-gray-800 shadow-2xl ring-1 ring-black ring-opacity-5 focus:outline-none border-2 border-gray-100 dark:border-gray-700 z-50">
          <div className="p-3">
            <div className="px-3 py-2 mb-2">
              <h3 className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Select Writing Style
              </h3>
            </div>
            {(Object.keys(availableProfiles) as WritingProfileType[]).map((profileKey) => {
              const profile = availableProfiles[profileKey];
              const Icon = PROFILE_ICONS[profileKey];
              const color = PROFILE_COLORS[profileKey];
              const isActive = activeProfile === profileKey;

              return (
                <Menu.Item key={profileKey}>
                  {({ active }) => (
                    <button
                      onClick={() => handleProfileChange(profileKey)}
                      className={`w-full text-left px-3 py-3 rounded-xl mb-2 transition-all ${
                        isActive
                          ? "bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/30 dark:to-pink-900/30 border-2 border-purple-300 dark:border-purple-600"
                          : active
                          ? "bg-gray-50 dark:bg-gray-700"
                          : "hover:bg-gray-50 dark:hover:bg-gray-700"
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        <div className={`bg-gradient-to-br ${color} p-2 rounded-lg flex-shrink-0 ${isActive ? "shadow-md" : ""}`}>
                          <Icon className="w-4 h-4 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-bold text-gray-900 dark:text-gray-100 text-sm">
                              {profile.name}
                            </span>
                            {isActive && (
                              <Check className="w-4 h-4 text-purple-600 dark:text-purple-400 flex-shrink-0" />
                            )}
                          </div>
                          <p className="text-xs text-gray-600 dark:text-gray-400 line-clamp-2">
                            {profile.description}
                          </p>
                          <div className="mt-1 flex flex-wrap gap-1">
                            <span className="text-xs px-2 py-0.5 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 rounded-full">
                              {profile.tone}
                            </span>
                            <span className="text-xs px-2 py-0.5 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 rounded-full">
                              {profile.vocabularyLevel}
                            </span>
                          </div>
                        </div>
                      </div>
                    </button>
                  )}
                </Menu.Item>
              );
            })}
          </div>
        </Menu.Items>
      </Transition>
    </Menu>
  );
}
